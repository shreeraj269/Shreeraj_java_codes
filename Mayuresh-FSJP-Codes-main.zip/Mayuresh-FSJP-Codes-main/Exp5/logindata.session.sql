CREATE DATABASE IF NOT EXISTS exp5db;
USE exp5db;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional test account:
-- INSERT INTO users (name, email, password)
-- VALUES ('Test User', 'test@example.com', '1234');

